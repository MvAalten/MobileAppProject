<?php get_header(); // archive.php toont categorieën, tags en auteurs ?>

<main class="container">
    <h1><?php the_archive_title(); // bijv. "Categorie: Verhaal" ?></h1>
    <?php the_archive_description(); // tekst van de categorie, tag of auteur (als die er is) ?>

    <?php
    // De Loop: alleen de berichten die bij deze categorie, tag of auteur horen.
    if ( have_posts() ) {
        while ( have_posts() ) {
            the_post();
            ?>
            <article class="post">
                <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                <?php the_excerpt(); ?>
            </article>
            <?php
        }
    } else {
        echo '<p>Geen berichten gevonden.</p>';
    }

    the_posts_pagination(); // knoppen naar oudere berichten
    ?>
</main>

<?php get_footer(); ?>
