# RDR2 Theme

Een simpel WordPress thema over Red Dead Redemption 2 (module WordPress Custom 1).

## Bestanden

| Bestand | Wat doet het? |
|---|---|
| `style.css` | Naam van het thema + alle opmaak |
| `functions.php` | Zet de titel, het menu en de CSS aan |
| `header.php` / `footer.php` | Bovenkant en onderkant van elke pagina |
| `front-page.php` | De voorpagina |
| `index.php` | Reserve-template (WordPress gebruikt dit als niets anders past) |
| `single.php` | Eén bericht |
| `page.php` | Een pagina (zoals "Over ons") |
| `archive.php` | Categorieën, tags en auteurs (filteren) |
| `404.php` | Pagina niet gevonden |

## Installeren (Local)

1. Zet de map `rdr2-theme` in `wp-content/themes/` (of upload de zip bij Weergave > Thema's).
2. Activeer het thema.
3. Maak een menu bij Weergave > Menu's en kies de plek "Hoofdmenu".
