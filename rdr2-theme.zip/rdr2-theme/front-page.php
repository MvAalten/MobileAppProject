<?php get_header(); // front-page.php is de voorpagina van de site ?>

<main class="container">
    <h1>Welkom in het Wilde Westen</h1>
    <p>Alles over Red Dead Redemption 2: Arthur Morgan, de Van der Linde-bende en meer.</p>

    <h2>Laatste berichten</h2>
    <?php
    // Eigen vraag aan WordPress: geef de 5 nieuwste berichten.
    $laatste = new WP_Query( array( 'posts_per_page' => 5 ) );

    if ( $laatste->have_posts() ) {
        while ( $laatste->have_posts() ) {
            $laatste->the_post();
            ?>
            <article class="post">
                <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                <?php the_excerpt(); ?>
            </article>
            <?php
        }
        wp_reset_postdata(); // zet WordPress weer terug naar normaal
    } else {
        echo '<p>Geen berichten gevonden.</p>';
    }
    ?>
</main>

<?php get_footer(); ?>
