<?php get_header(); // single.php toont één bericht ?>

<main class="container">
    <?php
    // De Loop: er is hier maar één bericht.
    while ( have_posts() ) {
        the_post();
        ?>
        <article class="post">
            <h1><?php the_title(); ?></h1>
            <p>Door <?php the_author(); ?> in <?php the_category( ', ' ); ?></p>
            <?php the_content(); ?>
            <p><?php the_tags( 'Tags: ', ', ' ); ?></p>
        </article>
        <?php
    }
    ?>
</main>

<?php get_footer(); ?>
