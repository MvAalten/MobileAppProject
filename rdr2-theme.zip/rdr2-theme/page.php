<?php get_header(); // page.php toont een pagina, zoals "Over ons" ?>

<main class="container">
    <?php
    // De Loop: er is hier maar één pagina.
    while ( have_posts() ) {
        the_post();
        ?>
        <article class="post">
            <h1><?php the_title(); ?></h1>
            <?php the_content(); ?>
        </article>
        <?php
    }
    ?>
</main>

<?php get_footer(); ?>
