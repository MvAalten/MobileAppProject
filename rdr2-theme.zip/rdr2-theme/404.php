<?php get_header(); // 404.php wordt getoond als een pagina niet bestaat ?>

<main class="container">
    <h1>Pagina niet gevonden</h1>
    <p>Deze pagina bestaat niet. Misschien is de outlaw er met de buit vandoor.</p>
    <p><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Terug naar de voorpagina</a></p>
</main>

<?php get_footer(); ?>
